// app

#import <UIKit/UIViewController.h>

@interface WorldClockPadViewController : UIViewController

@end
