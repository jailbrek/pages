#import <Foundation/Foundation.h>

API_AVAILABLE(ios(8.0))
@interface FigCaptureConnectionConfiguration : NSObject
@end
