#import "FigCaptureStillImageSettings.h"

API_AVAILABLE(ios(9.0))
@interface FigCaptureIrisStillImageSettings : FigCaptureStillImageSettings
@end
