#import "CKEntity.h"

@interface CKIMEntity : CKEntity

@end
