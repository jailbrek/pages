#import <Foundation/Foundation.h>

FOUNDATION_EXPORT NSString *PLLocalizedFrameworkString(NSString *key, NSString *comment);
