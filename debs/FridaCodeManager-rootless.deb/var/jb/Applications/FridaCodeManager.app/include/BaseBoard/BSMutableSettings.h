#import "BSSettings.h"

@interface BSMutableSettings : BSSettings

@end
