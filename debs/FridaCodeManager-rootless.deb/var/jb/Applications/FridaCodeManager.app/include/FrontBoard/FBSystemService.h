#import <Foundation/Foundation.h>

@interface FBSystemService : NSObject

@end