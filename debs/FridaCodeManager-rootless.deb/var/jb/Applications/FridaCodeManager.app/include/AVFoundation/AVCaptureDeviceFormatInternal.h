#import <Foundation/Foundation.h>

API_AVAILABLE(ios(7.0))
@interface AVCaptureDeviceFormatInternal : NSObject
@end
