#import "MPVideoView.h"

@interface MPVideoView (PlaybackControl)

@end
