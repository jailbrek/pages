#import "SBBBItemInfo.h"

@class BBBulletin;

@interface SBBBBulletinInfo : SBBBItemInfo

@property (nonatomic, retain, readonly) BBBulletin *representedBulletin;

@end
