#import "SBHUDView.h"

@interface SBBrightnessHUDView : SBHUDView

@end
