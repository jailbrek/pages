#import <UIKit/UIScrollView.h>

@interface SBAppSwitcherPeopleScrollView : UIScrollView

- (void)updateDataVisibleOnly:(BOOL)visibleOnly animated:(BOOL)animated;

@end
