#import "SBSystemGestureManager.h"

@interface SBMainDisplaySystemGestureManager : SBSystemGestureManager

@end
