#import "SBBBItemInfo.h"
#import <Foundation/NSString.h>

@interface SBBBSectionInfo : SBBBItemInfo

@property (nonatomic, retain) NSString *identifier;

@end
