#import <Foundation/NSObject.h>

@interface SBButtonBar : NSObject

@end
