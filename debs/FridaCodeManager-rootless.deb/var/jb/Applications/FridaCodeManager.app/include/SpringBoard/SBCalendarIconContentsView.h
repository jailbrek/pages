#import <Foundation/NSObject.h>

@interface SBCalendarIconContentsView : NSObject

@end
