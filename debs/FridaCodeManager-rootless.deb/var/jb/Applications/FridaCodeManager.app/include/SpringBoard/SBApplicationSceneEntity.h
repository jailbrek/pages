#import "SBWorkspaceEntity.h"

@class SBApplication;

@interface SBApplicationSceneEntity : SBWorkspaceEntity

@property (nonatomic, readonly) SBApplication *application;

@end
