#import "SBIconView.h"

@class SBFolder;

@interface SBFolderIconView : SBIconView

@property (nonatomic, retain, readonly) SBFolder *folder;

@end
