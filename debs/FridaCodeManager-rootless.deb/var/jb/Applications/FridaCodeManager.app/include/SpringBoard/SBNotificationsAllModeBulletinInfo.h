#import "SBNotificationsBulletinInfo.h"

@interface SBNotificationsAllModeBulletinInfo : SBNotificationsBulletinInfo

@end
