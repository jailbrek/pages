#import "SBWorkspaceEntity.h"

@interface SBWorkspaceDeactivatingEntity : SBWorkspaceEntity

- (BOOL)isDeactivatingEntity;

@end
