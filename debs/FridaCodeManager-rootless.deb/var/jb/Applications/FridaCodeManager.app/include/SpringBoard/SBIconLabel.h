#import <UIKit/UIControl.h>

@interface SBIconLabel : UIControl

@property BOOL inDock;

@end
