#import <Foundation/NSObject.h>

@interface SBAwayListItem : NSObject

@end
