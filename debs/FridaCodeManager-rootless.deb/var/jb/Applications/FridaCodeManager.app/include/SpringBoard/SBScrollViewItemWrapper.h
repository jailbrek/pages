#import <Foundation/NSObject.h>

@interface SBScrollViewItemWrapper : NSObject

@property (nonatomic, retain) id item;

@end
