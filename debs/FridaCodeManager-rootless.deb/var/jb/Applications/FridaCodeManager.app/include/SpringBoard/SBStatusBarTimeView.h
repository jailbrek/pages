#import <Foundation/NSObject.h>

@interface SBStatusBarTimeView : NSObject

@end
