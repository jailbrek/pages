#import <UIKit/UIView.h>

API_DEPRECATED_WITH_REPLACEMENT("SBIconListView", ios(2.0, 4.0)) @interface SBIconList : UIView

@end
