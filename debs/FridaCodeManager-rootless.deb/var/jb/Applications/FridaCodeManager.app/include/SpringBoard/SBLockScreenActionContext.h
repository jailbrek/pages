#import <Foundation/Foundation.h>

@class BBBulletin;

@interface SBLockScreenActionContext : NSObject

@property (nonatomic, retain) BBBulletin *bulletin;

@end
