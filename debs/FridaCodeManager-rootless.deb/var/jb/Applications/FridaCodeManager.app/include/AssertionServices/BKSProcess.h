#import <Foundation/NSObject.h>

@interface BKSProcess : NSObject

@property (nonatomic, assign) BOOL nowPlayingWithAudio;
@property (nonatomic, assign) BOOL recordingAudio;

@end
