#import "IMMessageItem.h"

@interface FZMessage : IMMessageItem

@end
