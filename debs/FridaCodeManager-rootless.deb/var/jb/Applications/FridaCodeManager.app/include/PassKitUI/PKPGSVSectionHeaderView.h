#import <UIKit/UIKit.h>

API_AVAILABLE(ios(11.0))
@interface PKPGSVSectionHeaderView : UIView
- (void)addTapped;
- (void)inboxTapped API_AVAILABLE(ios(15.0));
@end
