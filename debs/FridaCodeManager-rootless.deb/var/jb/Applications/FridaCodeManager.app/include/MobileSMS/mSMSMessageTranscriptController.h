#import <Foundation/NSObject.h>

@interface mSMSMessageTranscriptController : NSObject

@end
